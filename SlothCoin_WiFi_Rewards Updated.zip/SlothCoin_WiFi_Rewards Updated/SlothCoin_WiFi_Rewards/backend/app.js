
const { Connection, PublicKey, clusterApiUrl, Keypair, Transaction } = require("@solana/web3.js");
const { Token, TOKEN_PROGRAM_ID } = require("@solana/spl-token");
const express = require("express");

const app = express();
app.use(express.json());

const connection = new Connection(clusterApiUrl("mainnet-beta"), "confirmed");

// Replace with your token details
const TOKEN_MINT_ADDRESS = "ERvNZRNDjQ7EqsyjAhYiqPPooY1gsQ9j6QXc1cXywi8n";
const tokenMintPublicKey = new PublicKey(TOKEN_MINT_ADDRESS);

// Admin wallet (used to distribute rewards)
const adminPrivateKey = Uint8Array.from([/* Add your private key array here */]);
const adminWallet = Keypair.fromSecretKey(adminPrivateKey);

// Fee wallet
const feePublicKey = new PublicKey("6zkf4DviZZkpWVEh53MrcQV6vGXGpESnNXgAvU6KpBUH");

async function rewardUser(userWalletAddress, amount) {
    const userPublicKey = new PublicKey(userWalletAddress);

    const userTokenAccount = await Token.getAssociatedTokenAddress(
        TOKEN_PROGRAM_ID,
        tokenMintPublicKey,
        userPublicKey,
        adminWallet.publicKey
    );

    const tokenAccountInfo = await connection.getAccountInfo(userTokenAccount);
    if (!tokenAccountInfo) {
        const createAccountTransaction = new Transaction().add(
            Token.createAssociatedTokenAccountInstruction(
                adminWallet.publicKey,
                userTokenAccount,
                userPublicKey,
                tokenMintPublicKey
            )
        );
        await connection.sendTransaction(createAccountTransaction, [adminWallet]);
    }

    // Deduct fee (e.g., 10% of the reward amount)
    const feeAmount = amount * 0.1;
    const netAmount = amount - feeAmount;

    // Transfer tokens to the fee wallet
    const adminTokenAccount = await Token.getAssociatedTokenAddress(
        TOKEN_PROGRAM_ID,
        tokenMintPublicKey,
        adminWallet.publicKey
    );
    const feeTokenAccount = await Token.getAssociatedTokenAddress(
        TOKEN_PROGRAM_ID,
        tokenMintPublicKey,
        feePublicKey
    );

    const transferToFee = new Transaction().add(
        Token.createTransferInstruction(
            TOKEN_PROGRAM_ID,
            adminTokenAccount,
            feeTokenAccount,
            adminWallet.publicKey,
            [],
            feeAmount * 10 ** 9
        )
    );

    await connection.sendTransaction(transferToFee, [adminWallet]);
    console.log(`Transferred {feeAmount} SlothCoin to fee address.`);

    // Transfer remaining tokens to the user
    const transferTransaction = new Transaction().add(
        Token.createTransferInstruction(
            TOKEN_PROGRAM_ID,
            adminTokenAccount,
            userTokenAccount,
            adminWallet.publicKey,
            [],
            netAmount * 10 ** 9
        )
    );

    await connection.sendTransaction(transferTransaction, [adminWallet]);
    console.log(`Transferred {netAmount} SlothCoin to {userWalletAddress}`);
}

app.post("/reward", async (req, res) => {
    const { walletAddress, amount } = req.body;
    try {
        await rewardUser(walletAddress, amount);
        res.status(200).send(`Rewarded {amount} SlothCoin to {walletAddress} with a fee deducted.`);
    } catch (error) {
        console.error(error);
        res.status(500).send("Failed to reward user");
    }
});

app.listen(5000, () => {
    console.log("Backend running on port 5000");
});
    