
import React, { useState } from "react";

function App() {
    const [walletAddress, setWalletAddress] = useState(null);

    const connectWallet = async () => {
        const { solana } = window;
        if (solana && solana.isPhantom) {
            const response = await solana.connect();
            setWalletAddress(response.publicKey.toString());
        } else {
            alert("Please install Phantom Wallet to use this feature!");
        }
    };

    const requestReward = async () => {
        if (walletAddress) {
            const response = await fetch("http://localhost:5000/reward", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ walletAddress, amount: 1 }),
            });
            const message = await response.text();
            alert(message);
        } else {
            alert("Connect your wallet first!");
        }
    };

    return (
        <div style={{ textAlign: "center", marginTop: "50px" }}>
            <h1>Welcome to SlothCoin Rewards!</h1>
            {walletAddress ? (
                <>
                    <p>Your wallet: {walletAddress}</p>
                    <button onClick={requestReward}>Claim Reward</button>
                </>
            ) : (
                <button onClick={connectWallet}>Connect Wallet</button>
            )}
        </div>
    );
}

export default App;
    