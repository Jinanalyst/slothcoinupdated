
const { Connection, PublicKey, clusterApiUrl, Keypair, Transaction } = require("@solana/web3.js");
const { Token, TOKEN_PROGRAM_ID } = require("@solana/spl-token");
const express = require("express");

const app = express();
app.use(express.json());

const connection = new Connection(clusterApiUrl("mainnet-beta"), "confirmed");

// Replace with your token details
const TOKEN_MINT_ADDRESS = "ERvNZRNDjQ7EqsyjAhYiqPPooY1gsQ9j6QXc1cXywi8n";
const tokenMintPublicKey = new PublicKey(TOKEN_MINT_ADDRESS);

// Admin wallet (used to distribute rewards)
const adminPrivateKey = Uint8Array.from([...]); // Replace with your private key
const adminWallet = Keypair.fromSecretKey(adminPrivateKey);

async function rewardUser(userWalletAddress, amount) {
    const userPublicKey = new PublicKey(userWalletAddress);

    const userTokenAccount = await Token.getAssociatedTokenAddress(
        TOKEN_PROGRAM_ID,
        tokenMintPublicKey,
        userPublicKey,
        adminWallet.publicKey
    );

    const tokenAccountInfo = await connection.getAccountInfo(userTokenAccount);
    if (!tokenAccountInfo) {
        const createAccountTransaction = new Transaction().add(
            Token.createAssociatedTokenAccountInstruction(
                adminWallet.publicKey,
                userTokenAccount,
                userPublicKey,
                tokenMintPublicKey
            )
        );
        await connection.sendTransaction(createAccountTransaction, [adminWallet]);
    }

    const transferTransaction = new Transaction().add(
        Token.createTransferInstruction(
            TOKEN_PROGRAM_ID,
            await Token.getAssociatedTokenAddress(TOKEN_PROGRAM_ID, tokenMintPublicKey, adminWallet.publicKey, adminWallet.publicKey),
            userTokenAccount,
            adminWallet.publicKey,
            [],
            amount * 10 ** 9
        )
    );

    await connection.sendTransaction(transferTransaction, [adminWallet]);
    console.log(`Transferred ${amount} SlothCoin to ${userWalletAddress}`);
}

app.post("/reward", async (req, res) => {
    const { walletAddress, amount } = req.body;
    try {
        await rewardUser(walletAddress, amount);
        res.status(200).send(`Rewarded ${amount} SlothCoin to ${walletAddress}`);
    } catch (error) {
        console.error(error);
        res.status(500).send("Failed to reward user");
    }
});

app.listen(5000, () => {
    console.log("Backend running on port 5000");
});
    